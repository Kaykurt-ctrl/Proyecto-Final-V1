const demoName = "Ana Martínez";
const demoPassword = "123456";
const attendance = [
  ["20/11/2026","Matemática","Presente"],["20/11/2026","Lengua Española","Presente"],
  ["19/11/2026","Ciencias Naturales","Ausente"],["19/11/2026","Inglés","Presente"],
  ["18/11/2026","Ciencias Sociales","Presente"],["18/11/2026","Matemática","Sin registro"],
  ["17/11/2026","Lengua Española","Presente"],["17/11/2026","Inglés","Presente"]
];
const quizzes = {
  "Matemática":[{q:"¿Cuánto es 8 × 7?",a:["54","56","64"],correct:1,why:"8 × 7 = 56."},{q:"¿Cuál es el valor de x si x + 5 = 12?",a:["5","7","17"],correct:1,why:"Restamos 5 a ambos lados: x = 7."}],
  "Lengua Española":[{q:"¿Cuál es el propósito principal de un texto argumentativo?",a:["Narrar hechos","Defender una opinión con razones","Describir un lugar"],correct:1,why:"Un texto argumentativo presenta razones para defender una postura."}],
  "Ciencias Naturales":[{q:"¿Qué órgano bombea la sangre?",a:["Pulmón","Corazón","Hígado"],correct:1,why:"El corazón impulsa la sangre por el sistema circulatorio."}],
  "Ciencias Sociales":[{q:"¿En qué continente está República Dominicana?",a:["América","Europa","Asia"],correct:0,why:"República Dominicana está en el Caribe, en América."}],
  "Inglés":[{q:"Choose the correct form: She ___ to school every day.",a:["go","goes","going"],correct:1,why:"With she/he/it in the present simple, the verb usually takes -s."}]
};
let currentQuiz = null;
const $ = (id)=>document.getElementById(id);
function showToast(message){$("toastText").textContent=message;bootstrap.Toast.getOrCreateInstance($("appToast")).show()}
function enterApp(name){
  $("loginView").classList.add("d-none");$("appView").classList.remove("d-none");
  $("sideStudentName").textContent=name;$("welcomeName").textContent=name.split(" ")[0];
  document.querySelectorAll(".nav-link[data-page]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.page)));
  renderAttendance();renderDiagnostics();renderResources();renderCareerQuestions();
}
$("loginForm").addEventListener("submit",e=>{
  e.preventDefault();const name=$("studentName").value.trim(),pass=$("studentPassword").value;
  if(name.toLowerCase()===demoName.toLowerCase()&&pass===demoPassword){$("loginError").classList.add("d-none");enterApp(demoName)}
  else{$("loginError").textContent="Los datos no coinciden. Para probar utiliza Ana Martínez / 123456.";$("loginError").classList.remove("d-none")}
});
$("logoutBtn").addEventListener("click",()=>{ $("appView").classList.add("d-none");$("loginView").classList.remove("d-none");$("loginForm").reset();});
function navigate(page){
  document.querySelectorAll(".page-section").forEach(s=>s.classList.add("d-none"));
  $("page-"+page).classList.remove("d-none");
  document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  const label=document.querySelector(`.nav-link[data-page="${page}"]`)?.innerText.trim()||"Inicio";
  $("pageHeading").textContent=label;$("sidebar").classList.remove("open");window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.go)));
$("menuToggle").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
$("noticeBtn").addEventListener("click",()=>showToast("Tienes avisos académicos disponibles en el panel de inicio."));
function renderAttendance(){
  $("attendanceRows").innerHTML=attendance.map(r=>{
    const cls=r[2]==="Presente"?"status-present":r[2]==="Ausente"?"status-absent":"status-pending";
    return `<tr><td>${r[0]}</td><td>${r[1]}</td><td><span class="status-pill ${cls}">${r[2]}</span></td></tr>`;
  }).join("");
}
function renderDiagnostics(){
  const items=[["Matemática","Evalúa tus conocimientos matemáticos.","bi-calculator","purple"],["Lengua Española","Comprensión lectora y gramática.","bi-book","blue"],["Ciencias Naturales","Conceptos básicos de ciencias.","bi-flask","green"],["Inglés","Vocabulario y estructuras básicas.","bi-translate","orange"]];
  $("diagnosticCards").innerHTML=items.map(x=>`<div class="col-md-6 col-xl-3"><div class="learning-card"><div class="learning-icon ${x[3]}"><i class="bi ${x[2]}"></i></div><h3>${x[0]}</h3><p>${x[1]}</p><button class="btn btn-primary btn-sm" onclick="startQuiz('${x[0]}')">Comenzar prueba</button></div></div>`).join("");
}
function startQuiz(subject){
  currentQuiz=subject;const qs=quizzes[subject]||quizzes.Matemática;
  const target=$("page-diagnosticas").classList.contains("d-none")?$("nationalQuiz"):$("quizArea");
  target.classList.remove("d-none");
  target.innerHTML=`<div class="panel-title"><div><h3>Prueba de ${subject}</h3><p>Selecciona una respuesta por pregunta.</p></div><span class="term-pill">${qs.length} preguntas</span></div>
  <form id="quizForm">${qs.map((q,i)=>`<div class="quiz-question"><strong>${i+1}. ${q.q}</strong>${q.a.map((a,j)=>`<label><input type="radio" name="q${i}" value="${j}" required> ${a}</label>`).join("")}</div>`).join("")}<button class="btn btn-primary mt-2">Enviar respuestas</button></form><div id="quizResult" class="mt-3"></div>`;
  target.scrollIntoView({behavior:"smooth",block:"start"});
  $("quizForm").addEventListener("submit",e=>{
    e.preventDefault();const data=new FormData(e.target);let score=0;
    qs.forEach((q,i)=>{if(Number(data.get("q"+i))===q.correct)score++});
    $("quizResult").innerHTML=`<div class="quiz-result"><strong>Resultado: ${score} de ${qs.length}</strong><p class="mb-2">Esta práctica es orientativa. Revisa las explicaciones para reforzar tus conocimientos.</p>${qs.map((q,i)=>`<p class="small mb-1">${i+1}. ${q.why}</p>`).join("")}</div>`;
  });
}
window.startQuiz=startQuiz;
const resources=[
 ["Matemática","Funciones lineales: guía de estudio","Repasa conceptos y ejemplos paso a paso.","bi-graph-up"],
 ["Lengua Española","Comprensión de textos","Estrategias para identificar ideas principales.","bi-file-text"],
 ["Ciencias Naturales","El cuerpo humano","Material introductorio sobre los sistemas del cuerpo.","bi-heart-pulse"],
 ["Ciencias Sociales","Geografía del Caribe","Conoce el espacio geográfico de nuestra región.","bi-globe-americas"],
 ["Inglés","Everyday English","Vocabulario y expresiones de uso cotidiano.","bi-chat-square-text"]
];
function renderResources(){
 const filter=$("resourceFilter").value;
 $("resourceCards").innerHTML=resources.filter(r=>filter==="Todos"||r[0]===filter).map(r=>`<div class="col-md-6 col-xl-4"><div class="resource-card"><div class="resource-visual"><i class="bi ${r[3]}"></i></div><div class="resource-body"><small>${r[0].toUpperCase()}</small><h3>${r[1]}</h3><p>${r[2]}</p><a href="#" onclick="event.preventDefault();alert('Recurso de demostración. En la versión final se enlazará el material del centro.');">Abrir recurso <i class="bi bi-arrow-right"></i></a></div></div></div>`).join("");
}
$("resourceFilter").addEventListener("change",renderResources);
function renderCareerQuestions(){
 const qs=["Me gusta resolver problemas usando números y lógica.","Disfruto ayudar a otras personas y escuchar sus necesidades.","Me interesa crear, diseñar o comunicar ideas.","Me gusta investigar cómo funciona la naturaleza y la tecnología."];
 $("careerQuestions").innerHTML=qs.map((q,i)=>`<div class="quiz-question"><strong>${i+1}. ${q}</strong><label><input type="radio" name="career${i}" value="2"> Mucho</label><label><input type="radio" name="career${i}" value="1"> Un poco</label><label><input type="radio" name="career${i}" value="0"> Poco</label></div>`).join("");
}
$("careerSubmit").addEventListener("click",()=>{
 const vals=[0,1,2,3].map(i=>document.querySelector(`input[name="career${i}"]:checked`));
 if(vals.some(v=>!v)){ $("careerResult").innerHTML='<div class="alert alert-warning">Responde las cuatro preguntas para ver tus sugerencias.</div>';return;}
 const scores=vals.map(v=>Number(v.value));
 const max=Math.max(...scores),idx=scores.indexOf(max);
 const suggestions=[
 "Podrías explorar áreas como ingeniería, matemática, economía o informática.",
 "Podrías explorar educación, psicología, medicina o trabajo social.",
 "Podrías explorar comunicación, diseño, arte o mercadeo.",
 "Podrías explorar biología, ciencias, tecnología o investigación."
 ];
 $("careerResult").innerHTML=`<div class="quiz-result"><strong>Áreas que podrías explorar</strong><p class="mb-0">${suggestions[idx]}</p><small>Este resultado es orientativo. Conversa con docentes y orientadores antes de tomar decisiones.</small></div>`;
});
$("chatFab").addEventListener("click",()=>$("chatPanel").classList.toggle("d-none"));
$("chatClose").addEventListener("click",()=>$("chatPanel").classList.add("d-none"));
$("chatForm").addEventListener("submit",e=>{
 e.preventDefault();const text=$("chatText").value.trim();if(!text)return;
 const user=document.createElement("div");user.className="user-message";user.textContent=text;$("chatMessages").appendChild(user);
 const t=text.toLowerCase();let answer="Puedo orientarte sobre el uso de la plataforma. Prueba preguntar por el boletín, la asistencia, las pruebas o los recursos.";
 if(t.includes("nota")||t.includes("bolet"))answer="Para consultar tus notas, abre «Boletín escolar». Solo se muestran calificaciones oficiales publicadas por la administración.";
 else if(t.includes("asisten"))answer="En «Asistencia» puedes ver tus presencias, ausencias y clases sin registro. Una clase sin registro no se cuenta como ausencia.";
 else if(t.includes("prueba")||t.includes("nacional"))answer="Entra en «Pruebas diagnósticas» para evaluarte o en «Pruebas Nacionales» para practicar por asignatura.";
 else if(t.includes("recurso")||t.includes("video"))answer="Abre «Recursos de estudio» y filtra por asignatura para encontrar materiales de apoyo.";
 const bot=document.createElement("div");bot.className="bot-message";bot.textContent=answer;$("chatMessages").appendChild(bot);$("chatText").value="";$("chatMessages").scrollTop=$("chatMessages").scrollHeight;
});
