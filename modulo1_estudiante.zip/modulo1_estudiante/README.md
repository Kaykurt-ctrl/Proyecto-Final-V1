# Módulo 1 – Portal del estudiante

Prototipo web del módulo del estudiante, basado en los requisitos del proyecto final.

## Cómo abrirlo
1. Descarga y descomprime `modulo1_estudiante.zip`.
2. Instala [Visual Studio Code](https://code.visualstudio.com/).
3. En VS Code selecciona **Archivo > Abrir carpeta** y abre `modulo1_estudiante`.
4. Abre `index.html` en el navegador. Recomendado: instalar la extensión **Live Server**, hacer clic derecho en `index.html` y elegir **Open with Live Server**.

También puedes abrir `index.html` directamente con Chrome o Edge. Se necesita conexión a internet para cargar Bootstrap desde CDN y la tipografía.

## Acceso de demostración
- Nombre: `Ana Martínez`
- Contraseña: `123456`

## Funciones incluidas
- Inicio de sesión de demostración.
- Panel principal y resumen académico.
- Boletín de ejemplo e impresión / guardar como PDF.
- Consulta de asistencia con Presente, Ausente y Sin registro.
- Pruebas diagnósticas y prácticas con corrección automática de preguntas de ejemplo.
- Test vocacional orientativo.
- Biblioteca de recursos de demostración.
- Perfil del estudiante.
- Ayuda y asistente virtual de preguntas frecuentes.

## Importante: alcance del prototipo
Este proyecto es una **demostración frontend** con datos ficticios. El inicio de sesión se valida en JavaScript y no constituye seguridad real. No almacenes contraseñas ni datos personales reales aquí. Para producción se necesita un backend, base de datos, autenticación segura, control de roles y conexión con los módulos docente/administrativo y el programa C#.

Las notas del boletín son ilustrativas; el sistema definitivo debe mostrar únicamente calificaciones aprobadas y publicadas. La asistencia sin registro no se contabiliza como ausencia.

## Publicar en GitHub
1. Crea una cuenta en https://github.com/ si no tienes una.
2. Crea un repositorio nuevo, por ejemplo `modulo1-estudiante`.
3. Sube los archivos `index.html`, `styles.css`, `app.js` y `README.md`.
4. Para publicarlo como página web: entra a **Settings > Pages**, elige **Deploy from a branch**, selecciona `main` y la carpeta `/ (root)`, y guarda.
